import fs from 'node:fs';
import { createRequire } from 'node:module';
import path from 'node:path';

const require = createRequire(import.meta.url);
const { chromium } = require(
  'C:/Users/BAFFOUR/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright',
);

const outputDir = path.resolve('previews');
fs.mkdirSync(outputDir, { recursive: true });

const viewports = [320, 375, 390, 430, 768, 1024, 1280, 1440];
const expectedDownloadUrl =
  'https://drive.google.com/file/d/1biXBNqCmRLsSz1xwuyGsryDITwA8GMiU/view?usp=sharing';
const expectedDemoUrl = 'https://youtu.be/O2poPsuxCUA';
const expectedWhatsAppUrl =
  'https://wa.me/233209492966?text=Hello%2C%20I%20am%20interested%20in%20MasterSuite%20for%20my%20school.';
const officialLogoPath = '/assets/mastersuite-logo.png';
const expectedRelease = {
  version: '1.0.1',
  build: '2026.09.27.01',
  channel: 'Stable',
  releaseDate: '27 September 2026',
};
const browser = await chromium.launch({
  headless: true,
  executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe',
});
const results = [];

async function loadLazyImages(page) {
  await page.evaluate(async () => {
    const height = document.documentElement.scrollHeight;
    for (let y = 0; y <= height; y += 700) {
      window.scrollTo(0, y);
      await new Promise((resolve) => window.setTimeout(resolve, 60));
    }
    window.scrollTo(0, 0);
  });
  await page.waitForTimeout(150);
}

for (const width of viewports) {
  const page = await browser.newPage({
    viewport: { width, height: width < 600 ? 920 : 1000 },
    deviceScaleFactor: 1,
    isMobile: width < 768,
    hasTouch: width < 768,
  });

  await page.goto('http://localhost:3000/', { waitUntil: 'networkidle' });

  const metrics = await page.evaluate(() => ({
    width: window.innerWidth,
    scrollWidth: document.documentElement.scrollWidth,
    bodyScrollWidth: document.body.scrollWidth,
    title: document.title,
    downloadLinks: [...document.querySelectorAll('a')]
      .filter((link) => link.textContent?.includes('Download'))
      .map((link) => ({
        href: link.getAttribute('href'),
        target: link.getAttribute('target'),
        rel: link.getAttribute('rel'),
      })),
    demoLinks: [...document.querySelectorAll('a')]
      .filter((link) => link.textContent?.includes('Watch Demo'))
      .map((link) => ({
        href: link.getAttribute('href'),
        target: link.getAttribute('target'),
        rel: link.getAttribute('rel'),
      })),
    support: {
      mailto: document.querySelector('a[href^="mailto:"]')?.getAttribute('href'),
      tel: document.querySelector('a[href^="tel:"]')?.getAttribute('href'),
      whatsapp: document
        .querySelector('a[href^="https://wa.me/"]')
        ?.getAttribute('href'),
    },
    screenshotButtons: document.querySelectorAll(
      'button[aria-label^="Open "][aria-label$=" screenshot"]',
    ).length,
    logoImages: [...document.querySelectorAll('img[src="/assets/mastersuite-logo.png"]')].map(
      (image) => ({
        naturalWidth: image.naturalWidth,
        naturalHeight: image.naturalHeight,
      }),
    ),
    release: {
      hero: document.querySelector('#home')?.textContent ?? '',
      finalCta: document.querySelector('#download')?.textContent ?? '',
      whatsNew:
        document.querySelector('#whats-new-heading')?.textContent ?? '',
    },
  }));

  const visibleOfficialLogos = await page
    .locator(`img[src="${officialLogoPath}"]`)
    .evaluateAll((images) =>
      images.filter((image) => {
        const rect = image.getBoundingClientRect();
        const style = window.getComputedStyle(image);
        return (
          rect.width > 0 &&
          rect.height > 0 &&
          style.visibility !== 'hidden' &&
          style.display !== 'none'
        );
      }).length,
    );

  if (width === 1440) {
    await loadLazyImages(page);
    await page.screenshot({
      path: path.join(outputDir, 'mastersuite-desktop-1440.png'),
      fullPage: true,
    });
  }

  if (width === 390) {
    await loadLazyImages(page);
    await page.screenshot({
      path: path.join(outputDir, 'mastersuite-mobile-390.png'),
      fullPage: true,
    });
    await page.getByLabel('Open navigation menu').click();
    const mobileMenuLogoVisible = await page
      .locator(`nav img[src="${officialLogoPath}"]`)
      .evaluateAll((images) =>
        images.some((image) => {
          const rect = image.getBoundingClientRect();
          const style = window.getComputedStyle(image);
          return (
            rect.width > 0 &&
            rect.height > 0 &&
            style.visibility !== 'hidden' &&
            style.display !== 'none'
          );
        }),
      );
    await page.getByRole('link', { name: 'Features' }).click();
    await page.waitForTimeout(250);
    results.push({ mobileMenuLogoVisible });
  }

  if (width === 1024) {
    await page.getByLabel('Open Module Launcher screenshot').click();
    await page.getByLabel('Show next screenshot').click();
    const nextTitle =
      (await page.locator('[data-lightbox-title]').textContent()) ===
      'Student Management';
    await page.getByLabel('Show previous screenshot').click();
    const previousTitle =
      (await page.locator('[data-lightbox-title]').textContent()) ===
      'Module Launcher';
    await page.screenshot({
      path: path.join(outputDir, 'mastersuite-lightbox-1024.png'),
      fullPage: false,
    });
    await page.keyboard.press('Escape');
    await page.waitForTimeout(150);
    const closed = (await page.locator('[data-lightbox-title]').count()) === 0;
    results.push({ lightbox: { nextTitle, previousTitle, escapeClosed: closed } });
  }

  results.push({
    width,
    overflow:
      Math.max(metrics.scrollWidth, metrics.bodyScrollWidth) - metrics.width,
    title: metrics.title,
    downloadLinksValid:
      metrics.downloadLinks.length > 0 &&
      metrics.downloadLinks.every(
        (link) =>
          link.href === expectedDownloadUrl &&
          link.target === '_blank' &&
          link.rel?.includes('noopener') &&
          link.rel?.includes('noreferrer'),
      ),
    demoLinksValid:
      metrics.demoLinks.length > 0 &&
      metrics.demoLinks.every(
        (link) =>
          link.href === expectedDemoUrl &&
          link.target === '_blank' &&
          link.rel?.includes('noopener') &&
          link.rel?.includes('noreferrer'),
      ),
    supportValid:
      metrics.support.mailto === 'mailto:bafcreativegh@gmail.com' &&
      metrics.support.tel === 'tel:+233209492966' &&
      metrics.support.whatsapp === expectedWhatsAppUrl,
    releaseValid:
      [metrics.release.hero, metrics.release.finalCta].every(
        (text) =>
          text.includes(`MasterSuite ${expectedRelease.version}`) &&
          text.includes(`Build ${expectedRelease.build}`) &&
          text.includes(expectedRelease.channel),
      ) &&
      metrics.release.finalCta.includes(expectedRelease.releaseDate) &&
      metrics.release.whatsNew.includes(`Build ${expectedRelease.build}`),
    officialLogosValid:
      visibleOfficialLogos > 0 &&
      metrics.logoImages.length > 0 &&
      metrics.logoImages.every(
        (image) => image.naturalWidth === 512 && image.naturalHeight === 512,
      ),
    screenshotButtons: metrics.screenshotButtons,
  });

  await page.close();
}

await browser.close();
console.log(JSON.stringify(results, null, 2));
